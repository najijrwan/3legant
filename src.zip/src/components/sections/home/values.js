export const VALUES = [
    {
        iconName: 'FastDelivery',
        title:'Free Shipping',
        text: 'Order \n Above $200',
    },
    {
        iconName: 'Money',
        title: 'Money-back',
        text: '30 days guarantee',
    },
    {
        iconName: 'Lock01',
        title: 'Secure Payments',
        text: 'Secured \n by Stripe',
    },
    {
        iconName: 'Call',
        title: '24/7 Support',
        text: 'Phone and \n Email support',
    }
]