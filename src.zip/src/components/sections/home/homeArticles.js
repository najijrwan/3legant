export const HOME_ARTICLES = [
    {
        image: 'src/assets/images/article image 1.png',
        title: '7 ways to decor your home',
    },
    {
        image: 'src/assets/images/article image 2.png',
        title: 'Kitchen organization',
    },
    {
        image: 'src/assets/images/article image 3.png',
        title: 'Decor your bedroom',
    },
]