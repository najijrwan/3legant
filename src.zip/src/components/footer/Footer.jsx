import { FooterMain } from '@footer';

const Footer = () => {
    return <FooterMain />;
}

export default Footer;